## DevDmBootstrap3

This is a starter WordPress theme for DEVELOPERS using Twitter Bootstrap 3.0.

A lot of folks have been saying that there isn't a good theme out there for developers as most themes are trying to cater to the average Joe. Many available themes (even starter themes) are all full of bloated shortcodes and frameworks that make zero sense. This is my answer to that. I was very pleased with my 2.3.2 version so here is to a bright future using 3.x.

### Documentation / Demo (in progress)

Please refer to the full documentation if you have any questions about usage. I've tried to be as thorough as possible.

[http://devdm.com/DevDmBootstrap3/](http://devdm.com/DevDmBootstrap3/)

